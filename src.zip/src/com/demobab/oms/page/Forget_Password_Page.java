package com.demobab.oms.page;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import generics.BasePage;

public class Forget_Password_Page extends BasePage {

	public Forget_Password_Page(WebDriver driver) {
		super(driver);	
	}
	@FindBy(className="forget-password-link")private WebElement FPL;
	@FindBy(name="user[email]")private WebElement FPUEMAIL;
	@FindBy(xpath="//button[.='RESET']")private WebElement FPRESET;
	@FindBy(xpath="(//a[@class='forget-password-link'])[1]")private WebElement FPBACKLOGIN;
	
public void FPbtn() {
	FPL.click();
}
public void setuseremail(String userEmail) {

	FPUEMAIL.sendKeys(userEmail);

}
public void FPResetbtn() {
	FPRESET.click();
}
public void FPbacklogin() {
	FPBACKLOGIN.click();
}

}
