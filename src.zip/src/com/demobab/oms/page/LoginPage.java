package com.demobab.oms.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import generics.BasePage;

public class LoginPage extends BasePage {

	@FindBy(name = "email")
	private WebElement UN;

	@FindBy(name = "password")
	private WebElement PWD;

	@FindBy(name = "submit")
	private WebElement Lgn;
	/*
	 * @FindBy(xpath = "//a[@class='forget-password-link']") private WebElement
	 * FP;
	 */
	@FindBy(xpath = "//*[text()[contains(.,'Invalid ')]]")
	private WebElement InvalidLogin;
	@FindBy(xpath = "//*[text()[contains(.,'activated!')]]")
	private WebElement InactiveAcc;

	public LoginPage(WebDriver driver) {
		super(driver);

	}

	public void setusername(String un) {

		UN.sendKeys(un);

	}

	public void setpassword(String pw) {

		PWD.sendKeys(pw);
	}

	public void clicklgnbtn() {
		Lgn.click();
	}

	public void verifyErrormsgIsDisplayed() {

		verifyElement(InvalidLogin);
	}
	public void verifyinactiveErrormsgIsDisplayed() {

		verifyElement(InactiveAcc);
	}
}
