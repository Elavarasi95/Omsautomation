package com.demobab.oms.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


import generics.BasePage;
public class ChangePasswordpage extends BasePage{
	 @FindBy(id="navbarDropdownMenuLink")private WebElement UserDetail;
	@FindBy(xpath="//a[contains(.,'Change Password')]")private WebElement CngPW;
	 @FindBy(xpath="//input[@name='old_password']")private WebElement OPW;
	 @FindBy(xpath="//input[@name='password']")private WebElement NPW;
	 @FindBy(xpath="//input[@name='passwordConfirmation']")private WebElement CFP;
	 @FindBy(xpath="//button[.='Change Password']")private WebElement CPB;
	 @FindBy(xpath="//button[.=' Cancel ']")private WebElement Cancel;
	 @FindBy(xpath = "//*[text()[contains(.,'old password')]]")
		private WebElement oldpwempty;
	 
 public ChangePasswordpage(WebDriver driver) {
		super(driver);
	}

public void verifyUsernameIsDisplayed(){
 
 UserDetail.click();	
}

public void verifyElementIsDisplayed(){
	CngPW.click();
	
}
public void setoldpassword(String Curr_pw) {

	OPW.sendKeys(Curr_pw);
}

public void setnewpassword(String New_pw) {

	NPW.sendKeys(New_pw);
}
public void setconfirmpassword(String Confirm_pw) {

	CFP.sendKeys(Confirm_pw);
}
public void clickcpbtn() {
	CPB.click();
}
public void clickcancelbtn() {
	Cancel.click();
}
public void verifyErrorIsDisplayed(){
	verifyElement(oldpwempty);
}
}



