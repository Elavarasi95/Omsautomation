package com.demobab.oms.page;




import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import generics.BasePage;

public class Change_User_Password_Page extends BasePage {
	public Change_User_Password_Page(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//*[text()[contains(.,'Admin Settings')]]")
	private WebElement adminsetting;
	@FindBy(xpath = ".//*[@id='root']/div/div[1]/div[1]/nav/div/ul/li[3]/ul/li[3]/a")
	private WebElement Changeurpwmenu;
	@FindBy(xpath = "(//div[@class='Select-placeholder'])[2]")
	private WebElement cpUsername;
	@FindBy(id = "password")
	private WebElement cpnewpw;
	@FindBy(id = "password_confirmation")
	private WebElement cpppwc;
	@FindBy(xpath = ".//*[@id='root']/div/div[2]/div/div[2]/div/div/div[3]/button[1]")
	private WebElement Resetpwbutton;
	@FindBy(xpath = ".//*[@id='root']/div/div[2]/div/div[2]/div/div/div[3]/button[2]")
	private WebElement unlockuser;
	@FindBy(xpath = ".//*[@id='root']/div/div[2]/div/div[2]/div/div/div[3]/button[3]")
	private WebElement cpcancel;

	public void verifyadminsettingIsDisplayed() {

		adminsetting.click();
	}

	public void verifychangepasswordmenuIsDisplayed() {

		Changeurpwmenu.click();
	}

	public void verifychusernameIsDisplayed(String User) throws InterruptedException {
		/*
		 * Thread.sleep(2000); cpUsername.click(); Thread.sleep(10000);
		 * cpUsername.sendKeys(User); Thread.sleep(5000);
		 */
		try {
			Thread.sleep(2000);
			cpUsername.click();
			cpUsername.sendKeys(User);
			/*Robot r=new Robot();
			r.keyPress(KeyEvent.VK_E);
			r.keyPress(KeyEvent.VK_L);
			r.keyPress(KeyEvent.VK_A);*/
			Thread.sleep(5000);
			cpUsername.sendKeys(Keys.DOWN);
			Thread.sleep(3000);
			cpUsername.sendKeys(Keys.ENTER);
		} catch (Exception e) {
			
		}
	}

	public void sendnewpassword(String CNewpw) {
		cpnewpw.sendKeys(CNewpw);
	}

	public void sendconfirmpassword(String CHConfirmpw) {
		cpppwc.sendKeys(CHConfirmpw);
	}

	public void clickrsbtn() {
		Resetpwbutton.click();
	}

	public void clickulbtn() {
		unlockuser.click();
	}

	public void clickcancelbtn() {
		cpcancel.click();
	}
}
