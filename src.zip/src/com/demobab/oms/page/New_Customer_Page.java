package com.demobab.oms.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import generics.BasePage;

public class New_Customer_Page extends BasePage {

	public New_Customer_Page(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "(//*[text()[contains(.,'Customer Details')]])[1]")
	private WebElement CustomerButton;
	@FindBy(xpath = "(//*[text()[contains(.,'New Customer')]])[1]")
	private WebElement NewCustomerButton;
	@FindBy(xpath = "//input[@name='display_name']")
	private WebElement CustomerField;
	@FindBy(xpath="(//*[text()[contains(.,'Active')]])")private WebElement NewcusStatus;
	@FindBy(xpath="(//*[text()[contains(.,'Beverage')]])")private WebElement NewcusIndustry;
	@FindBy(id="basic-url")private WebElement Flat_Discount;
	@FindBy(id="point_of_contacts_first_name")private WebElement NewCusFN;
	@FindBy(id="point_of_contacts_last_name")private WebElement NewCusLN;
	@FindBy(xpath="(//*[text()[contains(.,'East')]])")private WebElement NewcusRegion;
	@FindBy(id="point_of_contacts_designation")private WebElement NewcusDesig;
	@FindBy(id="point_of_contacts_email")private WebElement NewcusEmail;
	/*@FindBy(id="point_of_contacts_mobile_no")private WebElement NewcusMobileNo;
	@FindBy(xpath="(//div[@class='Select-placeholder'])[2]")private WebElement NewcusMobileNo;
	*/
	
	
	
	
}
