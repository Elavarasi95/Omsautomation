package com.demobab.oms.Test;

import java.awt.AWTException;

import org.testng.annotations.Test;

import com.demobab.oms.page.Change_User_Password_Page;
import com.demobab.oms.page.LoginPage;

import generics.BaseTest;
import generics.UtilityLibiary;

public class Change_User_Password_Test extends BaseTest {
	String un = UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 1, 0);
	String pw = UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 1, 1);
	String lgTitle = UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 1, 2);
	/* String User =UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 7, 0); */
	String User = "elavarasi";
	String CNewpw = UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet2", 2, 0);
	String CHConfirmpw = UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet2", 2, 1);

	// Valid condition for Change User Password
	@Test(priority = 1)
	public void ChangePasseword() throws AWTException, InterruptedException {
		Change_User_Password_Page cu = new Change_User_Password_Page(driver);
		LoginPage l = new LoginPage(driver);
		l.setusername(un);
		l.setpassword(pw);
		l.clicklgnbtn();
		Thread.sleep(1000);
		System.out.println("Login Successfully");
		cu.verifyadminsettingIsDisplayed();
		System.out.println("Clicked Admin Setting");
		Thread.sleep(5000);
		cu.verifychangepasswordmenuIsDisplayed();
		System.out.println("Clicked Change user Password");
		Thread.sleep(3000);
		cu.verifychusernameIsDisplayed(User);
		Thread.sleep(3000);
		System.out.println("Entered Username");
		Thread.sleep(1000);
		cu.sendnewpassword(CNewpw);
		cu.sendconfirmpassword(CHConfirmpw);
		cu.clickrsbtn();
		System.out.println("Password Changed Successfully");
	}

}
