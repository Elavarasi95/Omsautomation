package com.demobab.oms.Test;

import org.testng.annotations.Test;

import com.demobab.oms.page.Forget_Password_Page;
import generics.BaseTest;
import generics.UtilityLibiary;

public class Forget_Password_Test extends BaseTest {
	//Valid User_Email
	@Test(priority=1)
	public void validForgotPassword() {
		String userEmail = UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 1, 0);
		Forget_Password_Page FP = new Forget_Password_Page(driver);
		FP.FPbtn();
		FP.setuseremail(userEmail);
		FP.FPResetbtn();
		System.out.println("Reset Password Successfully");
	}
//Empty User_Email Id
	@Test(priority=2)
	public void InvalidresetPassword() {
		Forget_Password_Page FP = new Forget_Password_Page(driver);
		FP.FPbtn();
		FP.FPResetbtn();
		System.out.println("Invalid Email");

	}
//Back to login page using back to login links
	@Test(priority=3)
	public void Backtologin() {
		Forget_Password_Page FP = new Forget_Password_Page(driver);
		FP.FPbtn();
		FP.FPbacklogin();
		System.out.println("Back to login page successfully");
	}
//Invalid Email Address
	@Test(priority=0)
	public void InvalidEmailresetPassword() {
		String inuserEmail = UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 6, 0);
		Forget_Password_Page FP = new Forget_Password_Page(driver);
		FP.FPbtn();
		FP.setuseremail(inuserEmail);
		FP.FPResetbtn();
		System.out.println("Invalid Email");
	}
}