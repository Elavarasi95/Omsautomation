package com.demobab.oms.Test;
import org.testng.annotations.Test;
import com.demobab.oms.page.LoginPage;
import generics.BaseTest;
import generics.UtilityLibiary;

public class LoginTest extends BaseTest {
	@Test(priority=0)
	public void validloginLogout() throws InterruptedException{
	
		//I am getting value Excel
		String un=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 1, 0);
		String pw=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 1, 1);
		String lgTitle=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 1, 2);
			
		//Enter valid User_name to UN filed	
		LoginPage l=new LoginPage(driver);
		l.setusername(un);	
		Thread.sleep(3000);
		//Enter valid Password
		l.setpassword(pw);
		Thread.sleep(3000);	
		//Click on Login Button
		l.clicklgnbtn();	
	    l.verifyTitle(lgTitle);	
	    System.out.println("Login Successfully using Email Id");
	}
@Test(priority=1)
	
	public void invalidPW(){
		String un=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1",2, 0);
		String pw=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 2, 1);
		LoginPage l=new LoginPage(driver);
		l.setusername(un);
		l.setpassword(pw);
		l.clicklgnbtn();
		l.verifyErrormsgIsDisplayed();
		System.out.println("Invalid Password");
		
	}
@Test(priority=2)
public void Validusername(){
	String un=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1",4, 0);
	String pw=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 4, 1);
	LoginPage l=new LoginPage(driver);
	l.setusername(un);
	l.setpassword(pw);
	l.clicklgnbtn();
	System.out.println("Login Successfully using Username");
}
@Test(priority=3)
	public void invalidUN() {
		String un=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1",3, 0);
		String pw=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 3, 1);
		LoginPage l=new LoginPage(driver);
		l.setusername(un);
		l.setpassword(pw);
		l.clicklgnbtn();
		l.verifyErrormsgIsDisplayed();
		System.out.println("Invalid Username");
	}
@Test(priority=4)
	public void EmptyUN() {
		String pw=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 3, 1);
		LoginPage l=new LoginPage(driver);
		l.setpassword(pw);
		l.clicklgnbtn();
		System.out.println(" Username Field is Empty");

		
	}
@Test(priority=5)
	public void EmptyPW() {
		String un=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 1, 0);
		LoginPage l=new LoginPage(driver);
		l.setusername(un);
		l.clicklgnbtn();
		System.out.println("Password is Empty");

	}
@Test(priority=6)
public void InactiveUser() {
	String un=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 5, 0);
	String pw=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 5, 1);
	LoginPage l=new LoginPage(driver);
	l.setusername(un);
	l.setpassword(pw);
	l.clicklgnbtn();
	l.verifyinactiveErrormsgIsDisplayed();
	System.out.println("Inactive User");

}
	
}
