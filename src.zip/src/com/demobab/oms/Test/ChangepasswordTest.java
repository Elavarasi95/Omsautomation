package com.demobab.oms.Test;


import org.testng.annotations.Test;

import com.demobab.oms.page.ChangePasswordpage;
import com.demobab.oms.page.LoginPage;

import generics.BaseTest;
import generics.UtilityLibiary;

public class ChangepasswordTest extends BaseTest {
	//Old password and new password get from excel
	String un=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 1, 0);
	 String pw=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 1, 1);
	 String lgTitle=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet1", 1, 2);
	 String Curr_pw=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet2", 1, 0);
	 String New_pw=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet2", 1, 1);
	 String Confirm_pw=UtilityLibiary.getcellvalue(INPUT_PATH, "Sheet2", 1, 2);
	 
//Old Password is Empty
 @Test(priority=1)
 public void OldpasswordEmpty(){
	 ChangePasswordpage cp=new ChangePasswordpage(driver);
	 LoginPage l=new LoginPage(driver);
	 l.setusername(un);
	 l.setpassword(pw);
	 l.clicklgnbtn();
	 l.verifyTitle(lgTitle);
	 cp.verifyUsernameIsDisplayed();
	 cp.verifyElementIsDisplayed();
	 cp.setnewpassword(New_pw);
	 cp.setconfirmpassword(Confirm_pw);
	 cp.clickcpbtn();
	 cp.verifyErrorIsDisplayed();
 }
 //New Password Is Empty
 @Test(priority=2)
 public void NewpasswordEmpty(){
	 ChangePasswordpage cp=new ChangePasswordpage(driver);
	 LoginPage l=new LoginPage(driver);
	 l.setusername(un);
	 l.setpassword(pw);
	 l.clicklgnbtn();
	 l.verifyTitle(lgTitle);
	 cp.verifyUsernameIsDisplayed();
	 cp.verifyElementIsDisplayed();
	 cp.setoldpassword(Curr_pw);
	 cp.setconfirmpassword(Confirm_pw);
	 cp.clickcpbtn();
 }
 //Confirm Password Is Empty
 @Test(priority=3)
 public void ConfirmpasswordEmpty(){
	 ChangePasswordpage cp=new ChangePasswordpage(driver);
	 LoginPage l=new LoginPage(driver);
	 l.setusername(un);
	 l.setpassword(pw);
	 l.clicklgnbtn();
	 l.verifyTitle(lgTitle);
	 cp.verifyUsernameIsDisplayed();
	 cp.verifyElementIsDisplayed();
	 cp.setoldpassword(Curr_pw);
	 cp.setnewpassword(New_pw);
	 cp.clickcpbtn();
}
 //NewPassword and Confirm Password Is Mismatch
 @Test(priority=4)
 public void passwordMismatch(){
	 ChangePasswordpage cp=new ChangePasswordpage(driver);
	 LoginPage l=new LoginPage(driver);
	 l.setusername(un);
	 l.setpassword(pw);
	 l.clicklgnbtn();
	 l.verifyTitle(lgTitle);
	 cp.verifyUsernameIsDisplayed();
	 cp.verifyElementIsDisplayed();
	 cp.setoldpassword(Curr_pw);
	 cp.setnewpassword(New_pw);
	 cp.setconfirmpassword(Curr_pw); 
	 cp.clickcpbtn();
}
//Old Password mismatch
 @Test(priority=0)
 public void OldPWMismatch(){
	 ChangePasswordpage cp=new ChangePasswordpage(driver);
	 LoginPage l=new LoginPage(driver);
	 l.setusername(un);
	 l.setpassword(pw);
	 l.clicklgnbtn();
	 l.verifyTitle(lgTitle);
	 cp.verifyUsernameIsDisplayed();
	 cp.verifyElementIsDisplayed();
	 cp.setoldpassword(New_pw);
	 cp.setnewpassword(New_pw);
	 cp.setconfirmpassword(Confirm_pw); 
}
 @Test(priority=5)
 public void Validchangepassword() throws InterruptedException
 {
	//Valid Change Password Screen
	 ChangePasswordpage cp=new ChangePasswordpage(driver);
	 LoginPage l=new LoginPage(driver);
	 l.setusername(un);
	 l.setpassword(pw);
	 l.clicklgnbtn();
	 l.verifyTitle(lgTitle);
	 Thread.sleep(1000);
	 System.out.println("Login Successfully");
	 Thread.sleep(1000);
	 cp.verifyUsernameIsDisplayed();
	 cp.verifyElementIsDisplayed();
	 cp.setoldpassword(Curr_pw);
	 cp.setnewpassword(New_pw);
	 cp.setconfirmpassword(Confirm_pw);
	 cp.clickcpbtn();
	 System.out.println("Password change sucessfully");
	 l.setusername(un);
	 l.setpassword(New_pw);
	 l.clicklgnbtn();
	 }

}






