package generics;

public interface IAutoConst {
	
	String CHROME_KEY="webdriver.chrome.driver";
	String CHROME_VALUE="./Jar/chromedriver1.exe";
	String GECKO_KEY="webdriver.gecko.driver";
	String GECKO_VALUE="./Jar/geckodriver.exe";
	String INPUT_PATH="./Data/TestData.xls";
	String PHOTO_PATH="./Snap/";
	String CONFIGPROPERTIES_PATH="./Config.properties";

}
