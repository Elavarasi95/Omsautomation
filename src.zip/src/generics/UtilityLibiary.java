package generics;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import javax.imageio.ImageIO;
import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class UtilityLibiary {
	// To take Screen Shot Using TakeSceenshot
	public static void getscreenshot(WebDriver driver, String path) {
		try {
			TakesScreenshot t = (TakesScreenshot) driver;
			File src = t.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src, new File(path));
		} catch (Exception e) {
		}
	}
	// To take Screen Shot Using Robot Class
	public static void getscreenshot(String path) {
		try {
			Robot r = new Robot();
			Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
			BufferedImage img = r.createScreenCapture(new Rectangle(d));
			ImageIO.write(img, "png", new File(path));
		}
		catch (Exception e) {
		}
	}
	// To Declare the date format
	public static String now() {
		SimpleDateFormat s = new SimpleDateFormat("dd_MM_yy_hh_mm_ss");
		return s.format(new Date());
	}
	// To read the Excel Sheet
	public static String getcellvalue(String Path, String Sheet, int r, int c) {
		String v = " ";
		try {
			Workbook wb = WorkbookFactory.create(new FileInputStream(Path));
			v = wb.getSheet(Sheet).getRow(r).getCell(c).toString();
		}
		catch (Exception e) {
		}
		return v;
	}
	public static String getpropertyvalues(String path, String key) {
		String V = " ";
		try {
			Properties p = new Properties();
			p.load(new FileInputStream(path));
			V = p.getProperty(key);
		} catch (Exception e) {
		}
		return V;
	}
	public static void robot(int K) {

		try {
			Robot r = new Robot();
			r.keyPress(K);
			r.keyRelease(K);
		} catch (Exception e) {
		}
	}
	
}
